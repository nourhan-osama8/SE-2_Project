package com.lostorfound.itemservice.model;


public enum Status {
    LOST,
    FOUND,
    CLAIMED
}
