package com.lostorfound.itemservice.service;
import com.lostorfound.itemservice.model.ItemModel;
import com.lostorfound.itemservice.model.Status;
import com.lostorfound.itemservice.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
@Service
public class ItemService {
    private final ItemRepository itemRepository;

    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    public List<ItemModel> getAllItems() {
        return itemRepository.findAll();
    }

    public void reportItem(ItemModel item) {
        item.setDateReported(LocalDateTime.now());
        itemRepository.save(item);
    }

    public boolean deleteItem(Long id) {
        if (itemRepository.existsById(id)) {
            itemRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public boolean updateItem(Long id, ItemModel updatedItem) {
        Optional<ItemModel> existingItem = itemRepository.findById(id);
        if (existingItem.isPresent()) {
            ItemModel item = existingItem.get();
            item.setName(updatedItem.getName());
            item.setDescription(updatedItem.getDescription());
            item.setLocation(updatedItem.getLocation());
            item.setCategory(updatedItem.getCategory());
            item.setStatus(updatedItem.getStatus());
            item.setReporterEmail(updatedItem.getReporterEmail());

            itemRepository.save(item);
            return true;
        }
        return false;
    }

    //    public List<ItemModel> searchItems(String keyword) {
//        return itemRepository.findByNameContainingIgnoreCaseOrDescriptionContainingIgnoreCase(keyword, keyword);
//    }
//
    public List<ItemModel> getItemsByStatus(String status) {
        try {
            Status statusEnum = Status.valueOf(status.toUpperCase());
            return itemRepository.findByStatus(statusEnum);
        } catch (IllegalArgumentException e) {
            return List.of(); // return empty if status is invalid
        }
    }
    public List<ItemModel> searchByCategory(String category) {
        return itemRepository.findByCategoryIgnoreCase(category);
    }

    public List<ItemModel> searchByKeyword(String keyword) {
        return itemRepository.findByNameContainingIgnoreCase(keyword);
    }

    public List<ItemModel> searchByLocation(String location) {
        return itemRepository.findByLocationContainingIgnoreCase(location);
    }

    // Add Item to the database (add new reported lost item)
    public ItemModel addItem(ItemModel item) {
        // Set default status to "LOST" for new reported items
        item.setStatus(Status.valueOf("LOST"));
        return itemRepository.save(item); // Save the item to the database
    }

    //    public boolean claimItem(Long id) {
//        Optional<ItemModel> itemOptional = itemRepository.findById(id);
//        if (itemOptional.isPresent()) {
//            ItemModel item = itemOptional.get();
//
//            // Only send email if item was previously LOST and now FOUND
//            if (item.getStatus() == Status.LOST) {
//                // Set item to FOUND
//                item.setStatus(Status.FOUND);
//                itemRepository.save(item);
//
//                // Send notification email
//                emailService.sendEmail(
//                        item.getReporterEmail(),
//                        "Lost Item Found Notification",
//                        "Good news! The item \"" + item.getName() + "\" you reported as lost has been found!"
//                );
//
//                return true;
//            }
//
//            // If item is not LOST, don't change or notify
//            return false;
//        }
//        return false;
//    }
    public boolean claimItem(Long id) {
        Optional<ItemModel> itemOptional = itemRepository.findById(id);
        if (itemOptional.isPresent()) {
            ItemModel item = itemOptional.get();
            System.out.println("Item found: " + item.getName() + ", status: " + item.getStatus());

            if (item.getStatus() == Status.FOUND) {
                System.out.println("Item already claimed.");
                return false;
            }

            item.setStatus(Status.FOUND);
            itemRepository.save(item);
            return true;
        }
        System.out.println("Item with ID " + id + " not found.");
        return false;
    }
}
